<?php
	$date = $_POST["pvm"];
	$tunnit = $_POST["tunnit"];
	$ylityo = $_POST["ylityo"];
	$vkl = $_POST["vkl"];
	$kohde = $_POST["kohde"];
	$km = $_POST["km"];
	$selite = $_POST["selite"];
	
	echo ($date);
	echo "<br>";
	echo ($tunnit);
	echo "<br>";
	echo ($ylityo);
	echo "<br>";
	echo ($vkl);
	echo "<br>";
	echo ($kohde);
	echo "<br>";
	echo ($km);
	echo "<br>";
	echo ($selite);
	
	
?>